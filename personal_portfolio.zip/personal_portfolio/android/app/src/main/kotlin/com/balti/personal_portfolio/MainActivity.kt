package com.balti.personal_portfolio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
