List<Map<String, dynamic>> projects = [
  {
    "title": "Self Portfolio",
    "types": ["web","mobile"],
    "image": "assets/images/project_portfolio.png",
    "in_progress": true,
  },
  {
    "title": "Promo",
    "types": ["web"],
    "image": "assets/images/project_promo.png",
    "in_progress": true,
  },
  {
    "title": "Focus control",
    "types": ["mobile"],
    "image": "assets/images/project_apps_blocker.png",
    "in_progress": false,
  },
  {
    "title": "Chatloop",
    "types": ["mobile"],
    "image": "assets/images/project_chatloop.png",
    "in_progress": false,
  },
  {
    "title": "Joby",
    "types": ["mobile"],
    "image": "assets/images/project_joby.png",
    "in_progress": false,
  },
  {
    "title": "Calculator",
    "types": ["mobile"],
    "image": "assets/images/project_calculator.png",
    "in_progress": false,
  },
  {
    "title": "Music player",
    "types": ["mobile"],
    "image": "assets/images/project_music_player.png",
    "in_progress": false,
  },
  {
    "title": "file generator",
    "types": ["desktop"],
    "image": "assets/images/project_file_generator.png",
    "in_progress": false,
  },
  {
    "title": "notepad",
    "types": ["desktop"],
    "image": "assets/images/project_notepad.png",
    "in_progress": false,
  },
  {
    "title": "Balci",
    "types": ["desktop"],
    "image": "assets/images/project_balci.png",
    "in_progress": false,
  },
];
