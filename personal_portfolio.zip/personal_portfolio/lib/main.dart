import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:personal_portfolio/sections/about.dart';
import 'package:personal_portfolio/sections/contact.dart';
import 'package:personal_portfolio/sections/projects.dart';
import 'package:personal_portfolio/sections/skills.dart';

import 'data/colors.dart';

//declare sections
enum Sections {About,Projects,Skills,Contact}

//declare colors ------------------------------------------
Color background = Colors.white;
Color background_card = const Color(0xfff9f4fb);
Color text = Colors.black;
Color text_secondary = const Color(0xff4e4e4e);
Color accent = const Color(0xFF4a3898);
Color accent_secondary= const Color(0xff5933ac);


//main function
void main() {
  runApp(const Home());
}


class Home extends StatefulWidget {
  //this page will hold the whole app
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  //getters and setters to get the right colors
  ThemeMode _themeMode = ThemeMode.light; // Default theme is light



  String _selected_section = Sections.About.name;
  Color about_nav_color = accent_secondary ;
  Color projects_nav_color = text ;
  Color skills_nav_color = text ;
  Color contact_nav_color = text ;


  void toggleTheme() {
    setState(() {
      _themeMode = _themeMode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    });
  }

  void navigate_to(String section){
    setState(() {
      about_nav_color = text ;
      projects_nav_color = text ;
      skills_nav_color = text ;
      contact_nav_color = text ;

      if(section==Sections.About.name){
        about_nav_color = accent_secondary;
      }else if(section==Sections.Projects.name){
        projects_nav_color = accent_secondary;
      }else if(section==Sections.Skills.name){
        skills_nav_color = accent_secondary;
      }else if(section==Sections.Contact.name){
        contact_nav_color = accent_secondary;
      }
      _selected_section = section;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Portfolio',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: Scaffold(
        backgroundColor: background,
          appBar: AppBar(
            forceMaterialTransparency: true, //remove the bg color changing effect when scrolling
            elevation: 0,
            backgroundColor: background,
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SvgPicture.asset(
                  'assets/images/logo.svg',
                  width: 160.0,
                  height: 160.0,
                ),
                Row(
                  children: [
                    Section(color:about_nav_color,name:Sections.About.name,action: (){
                      navigate_to(Sections.About.name);
                    },),
                    Section(color:projects_nav_color,name:Sections.Projects.name,action: (){
                      navigate_to(Sections.Projects.name);
                    },),
                    Section(color:skills_nav_color,name:Sections.Skills.name,action: (){
                      navigate_to(Sections.Skills.name);
                    },),
                    Section(color:contact_nav_color,name:Sections.Contact.name,action: (){
                      navigate_to(Sections.Contact.name);
                    },),
                  ],
                ),

                Row(
                  children: [
                    IconButton(
                      iconSize: 25,
                      icon: SvgPicture.asset(
                        'assets/icons/dark_mode.svg',
                        width: 23.0,
                        height: 23.0,
                      ),
                      tooltip: 'Dark/Light mode',
                      onPressed: toggleTheme,
                    ),
                    SizedBox(width: 15,),
                    OutlinedButton.icon(
                        onPressed: () {},
                        icon: SvgPicture.asset(
                          'assets/icons/send.svg',
                          width: 20.0,
                          height: 20.0,
                        ),
                        label: const Text("Let's talk"),
                        style: OutlinedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 15,horizontal: 10),
                          backgroundColor: background,
                          foregroundColor: text,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8.0), // Adjust the radius
                          ),
                        )
                    ),
                  ],
                )

              ],
            ),
          ),
          body:
          Align(
            alignment: Alignment.topCenter, // Centers horizontally and keeps vertical alignment as it is
            child: getSectionWidget(),
          )

      ),
    );
  }
  Widget getSectionWidget() {
    if(_selected_section == Sections.About.name){
      return About();
    } else if(_selected_section == Sections.Projects.name){
      return Projects();
    } else if(_selected_section == Sections.Skills.name){
      return Skills();
    }else if (_selected_section == Sections.Contact.name){
      return Contact();
    }else {
      return About();
    }
  }
}

class Section extends StatelessWidget{
  Section({super.key,required this.name,required this.action, required this.color});
  String name;
  Color color;
  final VoidCallback action;
  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
        onPressed: action,
        child: Text(name,style:TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w500,
          color: color
        )),
        style: OutlinedButton.styleFrom(
          padding: EdgeInsets.symmetric(vertical: 15,horizontal: 15),
          backgroundColor: background,
          foregroundColor: text,
          side: BorderSide.none
        )
    );
  }

}
